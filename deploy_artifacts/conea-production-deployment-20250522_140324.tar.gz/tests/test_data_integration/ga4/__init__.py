"""Tests for the GA4 integration module."""
