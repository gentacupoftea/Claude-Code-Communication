"""
Test package for Google Analytics integration.
"""