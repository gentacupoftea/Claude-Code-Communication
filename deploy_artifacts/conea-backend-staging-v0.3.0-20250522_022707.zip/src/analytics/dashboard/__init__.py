"""Dashboard analytics module."""

from .analytics_processor import AnalyticsProcessor

__all__ = ['AnalyticsProcessor']