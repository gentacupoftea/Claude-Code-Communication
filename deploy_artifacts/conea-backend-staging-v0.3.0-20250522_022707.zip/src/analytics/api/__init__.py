"""Analytics API module."""

from .analytics_routes import router

__all__ = ['router']