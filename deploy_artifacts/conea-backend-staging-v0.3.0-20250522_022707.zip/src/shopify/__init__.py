"""Shopify integration utilities"""
