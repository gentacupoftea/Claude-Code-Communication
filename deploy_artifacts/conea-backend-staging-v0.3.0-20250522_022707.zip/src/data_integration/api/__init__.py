"""API endpoints for data integration."""

from src.data_integration.api.endpoints import router

__all__ = ["router"]
