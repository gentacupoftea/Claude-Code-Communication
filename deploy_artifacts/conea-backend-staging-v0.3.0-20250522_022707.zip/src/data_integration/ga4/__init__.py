"""GA4 Integration module for Shopify data."""
