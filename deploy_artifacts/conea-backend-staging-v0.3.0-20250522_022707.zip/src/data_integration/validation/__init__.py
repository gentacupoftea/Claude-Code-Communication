"""Validation module for Shopify API data."""
