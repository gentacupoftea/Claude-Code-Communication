"""
Conea - formerly Shopify MCP Server

A powerful multi-platform connector for e-commerce integrations.
"""

__version__ = "0.3.0"