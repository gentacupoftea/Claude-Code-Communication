"""
Compatibility layer for Conea (formerly shopify-mcp-server)
"""