"""
AI providers and integration for Conea
"""